#!/bin/sh
iptables -t nat -D POSTROUTING -s 10.8.0.0/16 -o ens5 -j MASQUERADE
iptables -D INPUT -i tun443 -j ACCEPT
iptables -D FORWARD -i ens5 -o tun443 -j ACCEPT
iptables -D FORWARD -i tun443 -o ens5 -j ACCEPT
iptables -D INPUT -i ens5 -p udp --dport 443 -j ACCEPT
iptables -t nat -D POSTROUTING -s 10.7.0.0/16 -o ens5 -j MASQUERADE
iptables -D INPUT -i tun4430 -j ACCEPT
iptables -D FORWARD -i ens5 -o tun4430 -j ACCEPT
iptables -D FORWARD -i tun4430 -o ens5 -j ACCEPT
iptables -D INPUT -i ens5 -p tcp --dport 443 -j ACCEPT
