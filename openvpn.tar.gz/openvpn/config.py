bot_token = '6032934671:AAFe_lPcdPni70foK8rGwuDkk2GoF8TLNTs'
admin = 5054420103
